function varargout = Ex34CS63112(varargin)
% EX34CS63112 MATLAB code for Ex34CS63112.fig
%      EX34CS63112, by itself, creates a new EX34CS63112 or raises the existing
%      singleton*.
%
%      H = EX34CS63112 returns the handle to a new EX34CS63112 or the handle to
%      the existing singleton*.
%
%      EX34CS63112('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EX34CS63112.M with the given input arguments.
%
%      EX34CS63112('Property','Value',...) creates a new EX34CS63112 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Ex34CS63112_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Ex34CS63112_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Ex34CS63112

% Last Modified by GUIDE v2.5 20-Jul-2021 14:37:52

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Ex34CS63112_OpeningFcn, ...
                   'gui_OutputFcn',  @Ex34CS63112_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Ex34CS63112 is made visible.
function Ex34CS63112_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Ex34CS63112 (see VARARGIN)

% Choose default command line output for Ex34CS63112
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Ex34CS63112 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Ex34CS63112_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
clc
cam = webcam    % use webcam 
handles.vid = cam;
guidata(hObject, handles);
preview(handles.vid) % show webcam


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)

im=snapshot(handles.vid);  % capture
figure(2), imshow(im);  % show 
imwrite(im, 'Screenshot.jpg');  % save

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
closePreview(handles.vid); % stop webcam
clear



